/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oven;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;



public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField tfId;
    @FXML
    private TextField tfMerk;
    @FXML
    private ComboBox<oven> tfJenis;
    @FXML
    private DatePicker tfTanggal;
    @FXML
    private TextField tfUkuran;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private Button btnInsert;
    @FXML
    private TableView<oven> tableview;
    @FXML
    private TableColumn<oven, Integer> colId;
    @FXML
    private TableColumn<oven, String> colMerk;
    @FXML
    private TableColumn<oven, String> colJenis;
    @FXML
    private TableColumn<oven, String> colTanggal;
    @FXML
    private TableColumn<oven, String> colUkuran;
    
    
 
    
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource() == btnInsert){
            insertRecord();
        }else if (event.getSource() == btnUpdate){
            updateRecord();
        }else if(event.getSource() == btnDelete){
            deleteButton();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         showBooks();
        ArrayList <String> list = new ArrayList<String>();
        list.add("Oven Konvensional");
        list.add("Oven Gas");
        list.add("Oven Elektrik");
        list.add("Oven Konveksi");
        ObservableList items = FXCollections.observableArrayList(list);
        tfJenis.setItems(items);
    }    
    
    public Connection getConnection(){
        Connection conn;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oven", "root","");
            return conn;
        }catch(Exception ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }
    
    public ObservableList<oven> getBooksList(){
        ObservableList<oven> bookList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * FROM table_oven";
        Statement st;
        ResultSet rs;
        
        try{
            st = conn.createStatement();
            rs = st.executeQuery(query);
            oven ovn ;
            while(rs.next()){
                ovn = new oven(rs.getInt("id"), rs.getString("Merk"), rs.getString("Jenis"), rs.getString("tanggal"),rs.getString("Ukuran"));
                bookList.add(ovn);
            }
                
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return bookList;
    }
    
    public void showBooks(){
        ObservableList<oven> list = getBooksList();
        
        colId.setCellValueFactory(new PropertyValueFactory<oven, Integer>("id"));
        colMerk.setCellValueFactory(new PropertyValueFactory<oven, String>("Merk"));
        colJenis.setCellValueFactory(new PropertyValueFactory<oven, String>("Jenis"));
        colTanggal.setCellValueFactory(new PropertyValueFactory<oven, String>("tanggal"));
        colUkuran.setCellValueFactory(new PropertyValueFactory<oven, String>("Ukuran"));
        
        tableview.setItems(list);
    }
    
    private void insertRecord(){
        String query = "INSERT INTO oven VALUES (" + tfId.getText() + ",'" + tfMerk.getText() + "','" + tfJenis.getValue().toString() + "',"
                + tfTanggal.getValue().toString() + "," + tfUkuran.getText() + ")";
        executeQuery(query);
        showBooks();
    }
    
    private void updateRecord(){
        String query = "UPDATE  oven SET Merk  = '" + tfMerk.getText() + "', Jenis = '" + tfJenis.getValue().toString() + "', tanggal = " +
                tfTanggal.getValue().toString() + ", Ukuran = " + tfUkuran.getText() + " WHERE id = " + tfId.getText() + "";
        executeQuery(query);
        showBooks();
    }
    
    private void deleteButton(){
        String query = "DELETE FROM oven WHERE id =" + tfId.getText() + "";
        executeQuery(query);
        showBooks();
    }
    
    private void executeQuery(String query) {
        Connection conn = getConnection();
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(query);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}
