/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oven;

public class oven {
    private int id;
    private String Merk;
    private String Jenis;
    private String Tanggal;
    private String Ukuran;

    public oven (int id, String Merk, String Jenis, String Tanggal, String Ukuran) {
        this.id = id;
        this.Merk = Merk;
        this.Jenis = Jenis ;
        this.Tanggal = Tanggal;
        this.Ukuran = Ukuran ;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMerk() {
        return Merk;
    }

    public void setMerk(String Merk) {
        this.Merk = Merk;
    }

    public String getJenis() {
        return Jenis;
    }

    public void setJenis(String Jenis) {
        this.Jenis = Jenis;
    }

    public String getTanggal() {
        return Tanggal;
    }

    public void setTanggal(String Tanggal) {
        this.Tanggal = Tanggal;
    }

    public String getUkuran() {
        return Ukuran;
    }

    public void setUkuran(String Ukuran) {
        this.Ukuran = Ukuran;
    }

}
